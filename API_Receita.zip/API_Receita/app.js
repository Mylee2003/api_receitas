const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost/receitasfit', { useNewUrlParser: true, useUnifiedTopology: true });

const receitaSchema = new mongoose.Schema({
  nome: String,
  ingredientes: [String],
  instrucoes: String,
});

const Receita = mongoose.model('Receita', receitaSchema);

app.get('/api/receitas', async (req, res) => {
  const receitas = await Receita.find();
  res.json(receitas);
});

app.post('/api/receitas', async (req, res) => {
  const { nome, ingredientes, instrucoes } = req.body;
  const novaReceita = new Receita({ nome, ingredientes, instrucoes });
  const receitaSalva = await novaReceita.save();
  res.json(receitaSalva);
});

app.get('/api/receitas/:id', async (req, res) => {
  const receita = await Receita.findById(req.params.id);
  res.json(receita);
});

app.put('/api/receitas/:id', async (req, res) => {
  const { nome, ingredientes, instrucoes } = req.body;
  const receitaAtualizada = await Receita.findByIdAndUpdate(req.params.id, { nome, ingredientes, instrucoes }, { new: true });
  res.json(receitaAtualizada);
});

app.delete('/api/receitas/:id', async (req, res) => {
  await Receita.findByIdAndDelete(req.params.id);
  res.json({ message: 'Receita excluída com sucesso!' });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});